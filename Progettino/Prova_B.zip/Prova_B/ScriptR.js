//provo aleggre il piaatto che ho salvato prima
const piatto= JSON.parse(localStorage.getItem("piattoScelto"));

if(!piatto){
    document.getElementById("contenutoRicetta").innerHTML="<p>Nessuna ricetta selezionata.</p>";
}
else{//se non è vuoto metto restituisco idati 
    let pag="";
    pag+= "<h1>" + piatto.strMeal +"</h1>";
    
}

